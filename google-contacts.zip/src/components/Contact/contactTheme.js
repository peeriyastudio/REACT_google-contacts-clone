import { createTheme } from '@mui/material/styles';

const contactTheme = createTheme({
  typography: {
    fontFamily: '"Google Sans", sans-serif',
    fontSize: '.875rem',
  },
});

export default contactTheme;
